#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student2.h"

/* 학번을 입력받아 해당 학생의 레코드를 파일에서 읽어 출력한다. */
int dblist(int argc, char *argv[])
{
    int fd;
    struct student rec;
	off_t end_position;

   if (argc < 3) {
        fprintf(stderr,  "USAGE : %s -l filename\n", argv[0]);
        exit(1);
   }

   if ((fd = open(argv[2], O_RDONLY)) == -1) {
        perror(argv[2]);
        exit(2);
    }

   end_position = lseek(fd, 0, SEEK_END);

	lseek(fd, 0L, SEEK_SET);

	while(read(fd, &rec, sizeof(rec)) != -1){
		if(lseek(fd, 0, SEEK_CUR) == end_position){
			printf("학번:%d\t 이름:%s\t 점수:%d\n", 
		                 rec.id, rec.name, rec.score);
			break;
		}

		if(rec.name[0] != '$' && rec.id != 0)
		     printf("학번:%d\t 이름:%s\t 점수:%d\n", 
		                 rec.id, rec.name, rec.score);
	}
   
    close(fd);
    exit(0);
}
