void help(char* filename);
