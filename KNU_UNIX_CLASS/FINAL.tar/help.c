#include <stdio.h> 

void help(char* filename){
	printf("┏━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n");
	printf("┃ OPTION ┃         USAGE           ┃            EXPRESSION             ┃\n");
	printf("┣━━━━━━━━╋━━━━━━━━━━━━━━━━━━━━━━━━━╋━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫\n");
	printf("┃  [-c]  ┃ Create a DB with a file ┃  %s [-c] [DBname] < [stud.txt]  ┃\n", filename);   
	printf("┃        ┃ Create a DB by typing   ┃  %s [-c] [DBname]               ┃\n", filename);   
	printf("┃  [-d]  ┃ Delete a specific data  ┃  %s [-d] [DBname]               ┃\n", filename);   
	printf("┃  [-l]  ┃ Show a list of data     ┃  %s [-l] [DBname]               ┃\n", filename);   
	printf("┃  [-a]  ┃ Add a data              ┃  %s [-a] [DBname]               ┃\n", filename);   
	printf("┃  [-q]  ┃ Find a data             ┃  %s [-q] [DBname]               ┃\n", filename);   
	printf("┃  [-u]  ┃ Update DB               ┃  %s [-u] [DBname]               ┃\n", filename);   
	printf("┗━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n");
}
