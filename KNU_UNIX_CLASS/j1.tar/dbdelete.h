int dbdelete(int argc, char* argv[]);
