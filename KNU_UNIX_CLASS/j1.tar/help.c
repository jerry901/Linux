#include <stdio.h> 

void help(char* filename){
	printf("┏━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n");
	printf("┃ OPTION ┃         USAGE           ┃            EXPRESSION             ┃\n");
	printf("┣━━━━━━━━╋━━━━━━━━━━━━━━━━━━━━━━━━━╋━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫\n");
	printf("┃  [-c]  ┃ create a DB with a file ┃  %s [-c] [DBname] < [stud.txt]  ┃\n", filename);   
	printf("┃        ┃ create a DB by typing   ┃  %s [-c] [DBname]               ┃\n", filename);   
	printf("┃  [-d]  ┃ delete a specific data  ┃  %s [-d] [DBname]               ┃\n", filename);   
	printf("┃  [-l]  ┃ show a list of data     ┃  %s [-l] [DBname]               ┃\n", filename);   
	printf("┃  [-a]  ┃ add a data              ┃  %s [-a] [DBname]               ┃\n", filename);   
	printf("┃  [-u]  ┃ update DB               ┃  %s [-u] [DBname]               ┃\n", filename);   
	printf("┗━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n");
}
