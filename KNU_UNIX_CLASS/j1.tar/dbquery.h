int dbquery(int argc, char* argv[]);
