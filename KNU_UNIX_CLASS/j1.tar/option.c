#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "option.h"

int getOption(char* ptrOpt){
	if(ptrOpt[0] != '-'){
		return ERROR;
    }	
	else if(!strcmp(ptrOpt, "-help")){
		/** printf("help 옵션\n");  */
		return HELP;
	}
	else if(!strcmp(ptrOpt, "-c")){
		/** printf("create 옵션\n"); */
		return CREATE;
	}
	else if(!strcmp(ptrOpt, "-d")){
		/** printf("delete 옵션\n"); */
		return DELETE;
	}
	else if(!strcmp(ptrOpt, "-l")){
		/** printf("list 옵션\n"); */
		return LIST;
	}
	else if(!strcmp(ptrOpt, "-u")){
		/** printf("update 옵션\n"); */
		return UPDATE;
	}
	else if(!strcmp(ptrOpt, "-a")){
		/** printf("add 옵션\n"); */
		return ADD;
	}		
	else if(!strcmp(ptrOpt, "-q")){
		/** printf("query 옵션\n"); */
		return QUERY;
	}		
	else
		return ERROR;

}
