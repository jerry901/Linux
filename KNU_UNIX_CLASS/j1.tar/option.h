#define ERROR -1
#define HELP 0
#define CREATE 1
#define DELETE 2
#define UPDATE 3
#define LIST 4
#define ADD 5
#define QUERY 6

int getOption(char* ptrOpt);


