#include <stdio.h>
#include "main.h"

char line[MAXLINE];

int main(int argc, char* argv[]){ 
	char *ptr = argv[1];
	int option = ERROR;

	if(argc == 1){
		printf("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n");
		printf("┃                      HOW TO USE                        ┃\n");
		printf("┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫\n");
		printf("┃        \"%s [-option] [data1] [data2] ...\"            ┃\n", argv[0]);
		printf("┃          ex) main -help                                ┃\n");
		printf("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n");
		return 0;
	}
		
	option = getOption(ptr);	

	switch(option){
		case ERROR :
			fprintf(stderr, "ERROR : invalid option, (main -help)\n");
			break;
		case HELP :
			help(argv[0]);
			break;
		case CREATE :
			dbcreate(argc, argv);
			break;
		case DELETE :
			dbdelete(argc, argv);	
			break;
		case UPDATE :
			dbupdate(argc, argv);
			break;
		case LIST :
			dblist(argc, argv);	
			break;
		case ADD :
			dbadd(argc, argv);
			break;
		case QUERY :
			dbquery(argc, argv);
			break;
	}		
}
