#define MAX 24
struct student {
   char name[MAX];
   int id;
   int score;
};

