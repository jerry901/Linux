#define MAXLINE 1000 /* maximum length of input line */
void copy(char from[], char to[]);
