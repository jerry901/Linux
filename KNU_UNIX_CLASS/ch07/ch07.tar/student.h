#define START_ID 1401001

/* student 구조체 정의 */
struct student {
    int id;    
    char name[20];  
    int score; 
};


